import React from 'react'

const Mobile = () => {
  return (
    <>
      <div className="mobilemain">

      </div>
    </>
  )
}

export default Mobile
